import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { TravelPreferences, GeneratedItinerary } from '../types';
import { GEMINI_MODEL_NAME } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable not found. Please set it in your environment.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "YOUR_API_KEY_PLACEHOLDER_IF_NOT_SET" });

const constructPrompt = (preferences: TravelPreferences): string => {
  return `
You are an expert travel planning AI. Your goal is to generate a comprehensive and personalized travel itinerary.
Please create a detailed travel plan based on the following user preferences.

Return the response STRICTLY as a JSON object. Do NOT use markdown code fences (like \`\`\`json) around the JSON output.
The JSON object must adhere to the following TypeScript interface structure:

// ... (Keep existing interface definitions for FlightSuggestion, AccommodationSuggestion, ActivitySlot, MealSuggestions, ItineraryDay, BudgetBreakdown)

interface WeatherForecast {
  date: string; // "YYYY-MM-DD"
  dayName?: string; // e.g., "Monday"
  highTemp?: string; // e.g., "25°C / 77°F" - IMPORTANT: Include both Celsius and Fahrenheit
  lowTemp?: string; // e.g., "15°C / 59°F" - IMPORTANT: Include both Celsius and Fahrenheit
  condition?: string; // e.g., "Sunny", "Partly Cloudy", "Showers"
  icon?: string; // A simple text representation or keyword for an icon e.g., "sunny", "cloudy", "rain" (this helps UI pick an icon)
  precipitationChance?: string; // e.g., "10%"
}

interface GeneratedItinerary {
  tripName?: string; // e.g., "Adventure in ${preferences.destination}"
  destination: string;
  destinationCoordinates?: { lat: number; lon: number; }; // Geographic coordinates (latitude, longitude) of the destination. Example: { "lat": 48.8566, "lon": 2.3522 } for Paris. Provide this if possible.
  startDate: string; // "YYYY-MM-DD"
  endDate: string; // "YYYY-MM-DD"
  numberOfTravelers: number;
  travelStyle: string;
  budget?: string;
  overview?: string; // A brief summary of the trip (2-3 sentences)
  keyHighlightsSummary?: string[]; // Array of 3-5 strings, each a concise highlight/theme.
  suggestedFlights?: FlightSuggestion[];
  suggestedAccommodations?: AccommodationSuggestion[];
  dailyPlan: ItineraryDay[]; // Ensure one entry per day between startDate and endDate inclusive
  weatherForecast?: WeatherForecast[]; // Daily weather forecast for the trip duration
  packingList?: string[];
  budgetEstimate?: {
    total?: string;
    currency?: string;
    breakdown?: BudgetBreakdown;
  };
  visaRequirements?: string;
  healthAndSafety?: {
    vaccinations?: string[];
    travelInsurance?: string;
    localSafetyTips?: string[];
  };
  localCustoms?: string[];
  language?: {
    primarySpoken: string; // Primary language spoken at the destination
    secondarySpoken?: string[]; // Other commonly spoken or useful languages
    itineraryGeneratedInLanguage?: string; // The language this itinerary is primarily written in (e.g., "English", "Spanish")
    usefulPhrases?: { phrase: string; translation: string; targetLanguage?: string }[]; // Key phrases in the primary local language. targetLanguage should be the primarySpoken language.
  };
  currencyInfo?: {
    localCurrency: string;
    exchangeRate?: string;
    tippingEtiquette?: string;
  };
  transportationWithinDestination?: {
    recommendations: string[];
    apps?: string[];
  };
  emergencyContacts?: {
    police?: string;
    ambulance?: string;
    embassy?: string;
    localEmergencyNumber?: string;
  };
  additionalTips?: string[];
}

User Preferences:
Destination: ${preferences.destination}
Start Date: ${preferences.startDate}
End Date: ${preferences.endDate}
Number of Travelers: ${preferences.numTravelers}
Travel Style: ${preferences.travelStyle}
Budget: ${preferences.budget || 'Not specified'}
Specific Requests: ${preferences.specificRequests || 'None'}
Preferred Language for Itinerary: ${preferences.preferredLanguageForItinerary || 'English (default)'}

Key Instructions for AI:
1.  Generate a complete itinerary based on these preferences and the defined JSON structure.
2.  Destination Coordinates: If possible, provide the latitude and longitude for the main destination under 'destinationCoordinates'.
3.  Language:
    *   If "Preferred Language for Itinerary" is specified (and not 'English (default)'), generate all user-facing text content (overview, descriptions, notes, summaries, etc.) in THAT language.
    *   Set the 'itineraryGeneratedInLanguage' field to the language used for generation (e.g., "Spanish", "English").
    *   'usefulPhrases.targetLanguage' should match 'language.primarySpoken'.
4.  Dates: Ensure all date fields are in "YYYY-MM-DD" format. dailyPlan and weatherForecast should cover all days from startDate to endDate.
5.  Content: Provide practical and inspiring suggestions.
    *   For meal suggestions, mix specific (fictional but realistic) restaurant names and cuisine types.
    *   The 'overview' should be engaging.
    *   'keyHighlightsSummary' should be an array of 3-5 concise bullet points summarizing the trip's essence.
    *   'packingList' should be relevant.
    *   'budgetEstimate' should be a rough guide.
6.  Weather: Include a 'weatherForecast' for each day of the trip. Provide temperatures in both Celsius and Fahrenheit (e.g., "25°C / 77°F").
7.  Placeholders: For booking links, use placeholder URLs like "https://example.com/booking_search".
8.  Omissions: If information (e.g., flight details for a road trip) isn't applicable, omit the field or use an empty array where appropriate. If coordinates are not found, omit 'destinationCoordinates'.
  `;
};


export const generateTravelPlan = async (preferences: TravelPreferences): Promise<GeneratedItinerary> => {
  if (!API_KEY || API_KEY === "YOUR_API_KEY_PLACEHOLDER_IF_NOT_SET") {
    throw new Error("API key is not configured. Please set the API_KEY environment variable.");
  }

  const prompt = constructPrompt(preferences);

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7, 
        // topP: 0.95, 
        // topK: 40
      },
    });

    let jsonText = response.text;
    
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonText.match(fenceRegex);
    if (match && match[2]) {
      jsonText = match[2].trim();
    }
    
    const firstBrace = jsonText.indexOf('{');
    const lastBrace = jsonText.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      jsonText = jsonText.substring(firstBrace, lastBrace + 1);
    } else {
        console.error("Attempted to parse: ", jsonText);
        throw new Error("Invalid response format: No JSON object found or malformed structure.");
    }

    try {
        const itinerary: GeneratedItinerary = JSON.parse(jsonText);
        return itinerary;
    } catch (parseError) {
        console.error('Error parsing JSON response from AI:', parseError);
        console.error('Problematic JSON string:', jsonText);
        throw new Error(`Failed to parse the travel plan JSON. The AI's response might be malformed. Details: ${parseError instanceof Error ? parseError.message : String(parseError)}`);
    }

  } catch (error) {
    console.error('Error calling Gemini API or processing response:', error);
    if (error instanceof Error && error.message.includes("API key not valid")) {
        throw new Error("Invalid API Key. Please check your configuration.");
    }
    // Check for quota issues or other common API errors
    if (error instanceof Error && error.message.toLowerCase().includes("quota")) {
        throw new Error("API request failed due to quota limitations. Please check your Gemini API quota.");
    }
     if (error instanceof Error && error.message.toLowerCase().includes("candidatespraecipitated")) {
        throw new Error("The AI's response was blocked due to safety settings or content policy. Try modifying your request.");
    }
    throw new Error(`Failed to generate travel plan. ${error instanceof Error ? error.message : String(error)}`);
  }
};