
import React, { useState, useCallback } from 'react';
import { TravelPreferences, GeneratedItinerary } from './types';
import { generateTravelPlan } from './services/geminiService';
import Header from './components/Header';
import Footer from './components/Footer';
import TravelForm from './components/TravelForm';
import ItineraryDisplay from './components/ItineraryDisplay';
import ItinerarySummary from './components/ItinerarySummary'; // New component
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';
import Disclaimer from './components/Disclaimer';
import { SUMMARY_ICON_SVG, LIST_DETAILS_ICON_SVG } from './constants'; // Icons for toggles

type ViewState = 'form' | 'itinerary' | 'summary';

const App: React.FC = () => {
  const [itinerary, setItinerary] = useState<GeneratedItinerary | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<ViewState>('form');

  const handlePlanRequest = useCallback(async (preferences: TravelPreferences) => {
    setIsLoading(true);
    setError(null);
    setItinerary(null);
    setCurrentView('form'); // Stay on form view while loading
    try {
      const plan = await generateTravelPlan(preferences);
      setItinerary(plan);
      setCurrentView('itinerary'); // Show full itinerary first
    } catch (err) {
      console.error("Error generating travel plan:", err);
      setError(err instanceof Error ? err.message : "An unknown error occurred. Please ensure your API key is correctly configured and try again.");
      setCurrentView('form'); // Revert to form on error
    } finally {
      setIsLoading(false);
    }
  }, []);

  const renderContent = () => {
    if (isLoading) return <LoadingSpinner />;
    if (error) return <ErrorMessage message={error} />;

    if (itinerary) {
      if (currentView === 'itinerary') {
        return <ItineraryDisplay itinerary={itinerary} />;
      }
      if (currentView === 'summary') {
        return <ItinerarySummary itinerary={itinerary} />;
      }
    }
    // Default or initial view if not loading, no error, and no itinerary yet, or if form view is explicitly set.
    // Also, if formError exists in TravelForm, it will be displayed within TravelForm itself.
    if (currentView === 'form' && !itinerary && !isLoading && !error) {
       return (
         <div className="mt-12 text-center text-slate-500">
            <p className="text-lg">Your personalized itinerary will appear here once generated.</p>
            <img src={`https://picsum.photos/seed/travel${Math.random()}/600/400`} alt="Placeholder scenic travel" className="mt-6 rounded-lg shadow-lg mx-auto" />
        </div>
       );
    }
    return null; // Should not happen if logic is correct
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-sky-100 via-indigo-50 to-purple-100">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto bg-white/80 backdrop-blur-md shadow-2xl rounded-xl p-6 md:p-10">
          
          {currentView === 'form' && !isLoading && (
            <>
              <h1 className="text-4xl font-bold text-center text-indigo-700 mb-2">AI Travel Planner</h1>
              <p className="text-center text-slate-600 mb-8">
                Let's plan your next adventure! Fill in your preferences below.
              </p>
              <TravelForm onSubmit={handlePlanRequest} isLoading={isLoading} />
            </>
          )}

          {itinerary && (currentView === 'itinerary' || currentView === 'summary') && !isLoading && !error && (
            <div className="my-6 flex justify-center space-x-4">
              <button
                onClick={() => setCurrentView('summary')}
                disabled={currentView === 'summary'}
                className="flex items-center px-4 py-2 bg-indigo-500 text-white rounded-md hover:bg-indigo-600 disabled:bg-slate-300 transition-colors"
                aria-pressed={currentView === 'summary'}
              >
                <div className="w-5 h-5 mr-2" dangerouslySetInnerHTML={{ __html: SUMMARY_ICON_SVG.replace('class="w-6 h-6', 'class="w-5 h-5') }} />
                Summary
              </button>
              <button
                onClick={() => setCurrentView('itinerary')}
                disabled={currentView === 'itinerary'}
                className="flex items-center px-4 py-2 bg-purple-500 text-white rounded-md hover:bg-purple-600 disabled:bg-slate-300 transition-colors"
                aria-pressed={currentView === 'itinerary'}
              >
                 <div className="w-5 h-5 mr-2" dangerouslySetInnerHTML={{ __html: LIST_DETAILS_ICON_SVG.replace('class="w-6 h-6', 'class="w-5 h-5') }} />
                Full Itinerary
              </button>
            </div>
          )}
          
          <div className="mt-6">
            {renderContent()}
          </div>

        </div>
        {(itinerary || error) && <Disclaimer />}
      </main>
      <Footer />
    </div>
  );
};

export default App;
