import React from 'react';

const Disclaimer: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto mt-12 mb-8 p-4 bg-yellow-50 border-l-4 border-yellow-400 text-yellow-700 rounded-md shadow">
      <p className="text-sm">
        {/* Intentionally left blank as per user request */}
      </p>
    </div>
  );
};

export default Disclaimer;