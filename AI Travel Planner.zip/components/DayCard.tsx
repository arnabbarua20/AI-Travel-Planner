
import React from 'react';
import { ItineraryDay, ActivitySlot, MealSuggestions } from '../types';
import ActivityCard from './ActivityCard';
import { MORNING_ICON_SVG, AFTERNOON_ICON_SVG, EVENING_ICON_SVG, MEAL_ICON_SVG } from '../constants';

interface DayCardProps {
  day: ItineraryDay;
}

const MealSuggestionDisplay: React.FC<{ mealType: string; suggestion?: string | { name: string; type?: string; location?: string; } }> = ({ mealType, suggestion }) => {
  if (!suggestion) return null;

  let content;
  if (typeof suggestion === 'string') {
    content = <p className="text-slate-600">{suggestion}</p>;
  } else {
    content = (
      <div>
        <p className="text-slate-700 font-medium">{suggestion.name}</p>
        {suggestion.type && <p className="text-sm text-slate-500">{suggestion.type}</p>}
        {suggestion.location && <p className="text-sm text-slate-500 italic">{suggestion.location}</p>}
      </div>
    );
  }

  return (
    <div className="mt-2">
      <h5 className="font-semibold text-sm text-indigo-600">{mealType}:</h5>
      {content}
    </div>
  );
};


const DayCard: React.FC<DayCardProps> = ({ day }) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-200 hover:shadow-xl transition-shadow duration-300">
      <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-200">
        <h3 className="text-2xl font-bold text-indigo-700">Day {day.day}</h3>
        <span className="text-sm text-slate-500 font-medium">{day.date}</span>
      </div>
      {day.theme && <p className="text-lg font-semibold text-purple-600 mb-4">{day.theme}</p>}

      <div className="space-y-6">
        {day.morning && <ActivityCard timeOfDay="Morning" activity={day.morning} icon={() => <div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: MORNING_ICON_SVG }} />} />}
        {day.afternoon && <ActivityCard timeOfDay="Afternoon" activity={day.afternoon} icon={() => <div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: AFTERNOON_ICON_SVG }} />} />}
        {day.evening && <ActivityCard timeOfDay="Evening" activity={day.evening} icon={() => <div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: EVENING_ICON_SVG }} />} />}
      </div>

      {day.mealSuggestions && (day.mealSuggestions.breakfast || day.mealSuggestions.lunch || day.mealSuggestions.dinner) && (
        <div className="mt-6 pt-4 border-t border-slate-200">
          <h4 className="text-lg font-semibold text-indigo-600 mb-2 flex items-center">
            <div className="w-5 h-5" dangerouslySetInnerHTML={{ __html: MEAL_ICON_SVG }} /> <span className="ml-2">Meal Suggestions</span>
          </h4>
          <div className="grid sm:grid-cols-1 md:grid-cols-3 gap-4">
            <MealSuggestionDisplay mealType="Breakfast" suggestion={day.mealSuggestions.breakfast} />
            <MealSuggestionDisplay mealType="Lunch" suggestion={day.mealSuggestions.lunch} />
            <MealSuggestionDisplay mealType="Dinner" suggestion={day.mealSuggestions.dinner} />
          </div>
        </div>
      )}

      {day.notes && (
        <div className="mt-6 pt-4 border-t border-slate-200">
          <h4 className="text-md font-semibold text-slate-700 mb-1">Notes:</h4>
          <p className="text-sm text-slate-600 whitespace-pre-line">{day.notes}</p>
        </div>
      )}
    </div>
  );
};

export default DayCard;