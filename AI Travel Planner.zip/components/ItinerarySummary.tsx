import React from 'react';
import { GeneratedItinerary } from '../types';
import DestinationMap from './DestinationMap'; // Import DestinationMap
import { SUMMARY_ICON_SVG, BUDGET_ICON_SVG, INFO_ICON_SVG, WEATHER_ICON_SVG, LOCATION_PIN_ICON_SVG } from '../constants';

interface ItinerarySummaryProps {
  itinerary: GeneratedItinerary;
}

const SummarySection: React.FC<{ title: string; children: React.ReactNode; icon?: React.ReactNode }> = ({ title, children, icon }) => (
  <div className="mb-6 p-4 bg-white rounded-lg shadow-md">
    <h3 className="text-xl font-semibold text-indigo-700 mb-3 flex items-center">
      {icon && <span className="mr-2">{icon}</span>}
      {title}
    </h3>
    {children}
  </div>
);

const SummaryDetailItem: React.FC<{ label: string; value?: string | number; className?: string }> = ({ label, value, className }) => {
  if (!value && typeof value !== 'number') return null;
  return (
    <p className={`text-sm text-slate-700 ${className}`}>
      <span className="font-semibold">{label}:</span> {value}
    </p>
  );
};

const ItinerarySummary: React.FC<ItinerarySummaryProps> = ({ itinerary }) => {
  return (
    <div className="space-y-6 animate-fadeIn p-4">
      <header className="text-center mb-8">
        <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-indigo-600 to-sky-500 mb-2">
          Trip Summary: {itinerary.tripName || itinerary.destination}
        </h2>
        <p className="text-md text-slate-500">
          {itinerary.startDate} to {itinerary.endDate} | {itinerary.numberOfTravelers} Traveler(s)
        </p>
        {itinerary.language?.itineraryGeneratedInLanguage && <p className="text-xs text-slate-400 mt-1">(Itinerary generated in: {itinerary.language.itineraryGeneratedInLanguage})</p>}
      </header>

      <SummarySection title="Quick Info" icon={<div className="w-5 h-5" dangerouslySetInnerHTML={{ __html: INFO_ICON_SVG.replace('class="w-6 h-6', 'class="w-5 h-5 text-indigo-500')}} />}>
        <SummaryDetailItem label="Destination" value={itinerary.destination} />
        <SummaryDetailItem label="Travel Style" value={itinerary.travelStyle} />
        {itinerary.budget && <SummaryDetailItem label="Budget Tier" value={itinerary.budget} />}
      </SummarySection>

      {itinerary.destinationCoordinates && (
        <SummarySection title="Location on Map" icon={<div className="w-5 h-5" dangerouslySetInnerHTML={{ __html: LOCATION_PIN_ICON_SVG.replace('class="w-6 h-6', 'class="w-5 h-5 text-red-500')}} />}>
            <DestinationMap 
                latitude={itinerary.destinationCoordinates.lat}
                longitude={itinerary.destinationCoordinates.lon}
                destinationName={itinerary.destination}
            />
        </SummarySection>
      )}

      {itinerary.overview && (
        <SummarySection title="Overview" icon={<div className="w-5 h-5" dangerouslySetInnerHTML={{ __html: SUMMARY_ICON_SVG.replace('class="w-6 h-6', 'class="w-5 h-5 text-indigo-500')}} />}>
          <p className="text-sm text-slate-600 leading-relaxed">{itinerary.overview}</p>
        </SummarySection>
      )}
      
      {itinerary.keyHighlightsSummary && itinerary.keyHighlightsSummary.length > 0 && (
        <SummarySection title="Key Highlights" icon={<div className="w-5 h-5" dangerouslySetInnerHTML={{ __html: SUMMARY_ICON_SVG.replace('class="w-6 h-6', 'class="w-5 h-5 text-indigo-500')}} />}>
          <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
            {itinerary.keyHighlightsSummary.map((highlight, index) => (
              <li key={index}>{highlight}</li>
            ))}
          </ul>
        </SummarySection>
      )}

      {itinerary.budgetEstimate && (
        <SummarySection title="Estimated Budget" icon={<div className="w-5 h-5" dangerouslySetInnerHTML={{ __html: BUDGET_ICON_SVG.replace('class="w-6 h-6', 'class="w-5 h-5 text-indigo-500')}} />}>
          <SummaryDetailItem label="Total" value={`${itinerary.budgetEstimate.total || 'N/A'} ${itinerary.budgetEstimate.currency || ''}`} className="text-lg font-bold" />
          {itinerary.budgetEstimate.breakdown && (
            <div className="mt-2">
              <h4 className="text-xs font-semibold text-slate-500 uppercase mb-1">Breakdown:</h4>
              <div className="grid grid-cols-2 gap-x-4 gap-y-0.5">
              {Object.entries(itinerary.budgetEstimate.breakdown).map(([key, value]) => (
                <SummaryDetailItem key={key} label={key.charAt(0).toUpperCase() + key.slice(1)} value={value as string} />
              ))}
              </div>
            </div>
          )}
        </SummarySection>
      )}

      {itinerary.weatherForecast && itinerary.weatherForecast.length > 0 && (
         <SummarySection title="Weather At a Glance" icon={<div className="w-5 h-5" dangerouslySetInnerHTML={{ __html: WEATHER_ICON_SVG.replace('class="w-6 h-6', 'class="w-5 h-5 text-sky-500')}} />}>
           <p className="text-sm text-slate-600">
             Generally, expect <span className="font-semibold">{itinerary.weatherForecast[0]?.condition}</span> conditions around the start of your trip, with temperatures from <span className="font-semibold">{itinerary.weatherForecast[0]?.lowTemp}</span> to <span className="font-semibold">{itinerary.weatherForecast[0]?.highTemp}</span>.
           </p>
           <p className="text-xs text-slate-500 mt-1">Check the full itinerary for daily details.</p>
        </SummarySection>
      )}

    </div>
  );
};

export default ItinerarySummary;