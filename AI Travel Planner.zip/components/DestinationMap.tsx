import React from 'react';

interface DestinationMapProps {
  latitude?: number;
  longitude?: number;
  destinationName: string;
}

const DestinationMap: React.FC<DestinationMapProps> = ({ latitude, longitude, destinationName }) => {
  if (typeof latitude !== 'number' || typeof longitude !== 'number') {
    return (
        <p className="text-sm text-slate-500 italic text-center py-4">
            Map data is currently unavailable for {destinationName}.
        </p>
    );
  }

  // A common default zoom level for cities. Adjust as needed.
  const zoomLevel = 12; 
  const mapUrl = `https://www.openstreetmap.org/export/embed.html?mlat=${latitude}&mlon=${longitude}&zoom=${zoomLevel}&layer=mapnik&marker=${latitude},${longitude}`;

  return (
    <div className="my-6 rounded-lg overflow-hidden shadow-lg">
      <iframe
        width="100%"
        height="350"
        frameBorder="0"
        scrolling="no"
        marginHeight={0}
        marginWidth={0}
        src={mapUrl}
        title={`Map of ${destinationName}`}
        aria-label={`Interactive map showing ${destinationName}`}
        style={{ border: 0 }}
        allowFullScreen
      ></iframe>
       <p className="text-xs text-slate-500 p-2 bg-slate-50 text-center">
        Map data &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer" className="text-indigo-500 hover:underline">OpenStreetMap</a> contributors.
      </p>
    </div>
  );
};

export default DestinationMap;