
import React from 'react';
import { GLOBE_ICON_SVG } from '../constants';

const Header: React.FC = () => {
  return (
    <header className="bg-indigo-600 text-white shadow-lg">
      <div className="container mx-auto px-4 py-5 flex items-center">
        <div className="w-8 h-8 mr-3" dangerouslySetInnerHTML={{ __html: GLOBE_ICON_SVG }} />
        <h1 className="text-2xl font-semibold tracking-tight">AI Travel Planner</h1>
      </div>
    </header>
  );
};

export default Header;
