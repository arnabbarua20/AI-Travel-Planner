
import React from 'react';
import { ActivitySlot } from '../types';

interface ActivityCardProps {
  timeOfDay: string;
  activity: ActivitySlot;
  icon?: React.FC;
}

const ActivityCard: React.FC<ActivityCardProps> = ({ timeOfDay, activity, icon: IconComponent }) => {
  return (
    <div className="bg-slate-50 p-4 rounded-lg shadow-sm border border-slate-100">
      <div className="flex items-center mb-2">
        {IconComponent && <IconComponent />}
        <h4 className={`text-lg font-semibold ${IconComponent ? 'ml-2' : ''} text-slate-800`}>{timeOfDay}: {activity.activity}</h4>
      </div>
      <p className="text-sm text-slate-600 mb-2">{activity.description}</p>
      <div className="text-xs text-slate-500 space-y-0.5">
        {activity.location && <p><span className="font-medium">Location:</span> {activity.location}</p>}
        {activity.estimatedTime && <p><span className="font-medium">Time:</span> {activity.estimatedTime}</p>}
        {activity.costEstimate && <p><span className="font-medium">Cost:</span> {activity.costEstimate}</p>}
      </div>
       {activity.bookingLink && (
          <a 
            href={activity.bookingLink} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="mt-2 inline-block text-xs text-indigo-500 hover:text-indigo-700 hover:underline"
          >
            Book / More Info
          </a>
        )}
    </div>
  );
};

export default ActivityCard;
