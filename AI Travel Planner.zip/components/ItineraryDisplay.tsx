import React from 'react';
import { GeneratedItinerary } from '../types';
import DayCard from './DayCard';
import DestinationMap from './DestinationMap'; // Import DestinationMap
import { 
    WEATHER_ICON_SVG, 
    BUDGET_ICON_SVG, 
    INFO_ICON_SVG, 
    LOCATION_PIN_ICON_SVG,
    FLIGHT_ICON_SVG,
    ACCOMMODATION_ICON_SVG,
    PACKING_ICON_SVG
} from '../constants'; // Import icons

interface ItineraryDisplayProps {
  itinerary: GeneratedItinerary;
}

const InfoSection: React.FC<{ title: string; children: React.ReactNode; icon?: React.ReactNode; titleClassName?: string }> = ({ title, children, icon, titleClassName = "text-indigo-700" }) => (
  <div className="mb-8 p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
    <h3 className={`text-2xl font-semibold ${titleClassName} mb-4 flex items-center`}>
      {icon && <span className="mr-3">{icon}</span>}
      {title}
    </h3>
    {children}
  </div>
);

const DetailItem: React.FC<{ label: string; value?: string | number | React.ReactNode; className?: string; subItems?: boolean }> = ({ label, value, className, subItems }) => {
  if (!value && typeof value !== 'number' && value !== null) return null; // Allow null to render explicitly if needed for layout by parent
  return (
    <div className={`mb-2 ${className}`}>
      <span className={`font-semibold ${subItems ? 'text-slate-600' : 'text-slate-700'}`}>{label}:</span>{' '}
      <span className="text-slate-600">{value}</span>
    </div>
  );
};

const ItineraryDisplay: React.FC<ItineraryDisplayProps> = ({ itinerary }) => {
  return (
    <div className="space-y-10 animate-fadeIn">
      <header className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-indigo-600 to-sky-500 mb-3">
          {itinerary.tripName || `Your Trip to ${itinerary.destination}`}
        </h2>
        <p className="text-lg text-slate-600">
          {itinerary.startDate} to {itinerary.endDate} | {itinerary.numberOfTravelers} Traveler(s)
        </p>
        {itinerary.travelStyle && <p className="text-md text-indigo-500 font-medium">{itinerary.travelStyle}</p>}
        {itinerary.budget && <p className="text-md text-green-600 font-medium">Budget: {itinerary.budget}</p>}
        {itinerary.language?.itineraryGeneratedInLanguage && <p className="text-sm text-slate-500 mt-1">(Itinerary generated in: {itinerary.language.itineraryGeneratedInLanguage})</p>}
      </header>

      {itinerary.overview && (
        <InfoSection title="Trip Overview" icon={<div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: INFO_ICON_SVG }} />}>
          <p className="text-slate-600 leading-relaxed">{itinerary.overview}</p>
        </InfoSection>
      )}

      {itinerary.destinationCoordinates && (
        <InfoSection title="Destination Map" icon={<div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: LOCATION_PIN_ICON_SVG }} />} titleClassName="text-red-600">
          <DestinationMap 
            latitude={itinerary.destinationCoordinates.lat} 
            longitude={itinerary.destinationCoordinates.lon} 
            destinationName={itinerary.destination} 
          />
        </InfoSection>
      )}

      {itinerary.suggestedFlights && itinerary.suggestedFlights.length > 0 && (
        <InfoSection title="Suggested Flights" icon={<div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: FLIGHT_ICON_SVG }} />}>
          <div className="space-y-6">
            {itinerary.suggestedFlights.map((flight, index) => (
              <div key={index} className="p-4 border border-slate-200 rounded-lg shadow-sm bg-slate-50">
                <h4 className="font-semibold text-lg text-indigo-600">{flight.airline || 'Flight Option'} {flight.flightNumber && `(${flight.flightNumber})`}</h4>
                <DetailItem label="From" value={flight.departureCity} />
                <DetailItem label="To" value={flight.arrivalCity} />
                <DetailItem label="Departure" value={flight.departureDateTime} />
                <DetailItem label="Arrival" value={flight.arrivalDateTime} />
                <DetailItem label="Duration" value={flight.duration} />
                <DetailItem label="Est. Price" value={flight.priceEstimate} />
                {flight.bookingLink && (
                  <a href={flight.bookingLink} target="_blank" rel="noopener noreferrer" className="text-sm text-indigo-500 hover:text-indigo-700 hover:underline">
                    Search Flights
                  </a>
                )}
              </div>
            ))}
          </div>
        </InfoSection>
      )}

      {itinerary.suggestedAccommodations && itinerary.suggestedAccommodations.length > 0 && (
         <InfoSection title="Suggested Accommodations" icon={<div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: ACCOMMODATION_ICON_SVG }} />}>
          <div className="grid md:grid-cols-2 gap-6">
            {itinerary.suggestedAccommodations.map((acc, index) => (
              <div key={index} className="p-4 border border-slate-200 rounded-lg shadow-sm bg-slate-50">
                <h4 className="font-semibold text-lg text-indigo-600">{acc.name} ({acc.type})</h4>
                <DetailItem label="Location" value={acc.location} />
                <DetailItem label="Price Range" value={acc.priceRange} />
                <DetailItem label="Rating" value={acc.rating?.toString()} />
                {acc.amenities && acc.amenities.length > 0 && (
                    <DetailItem label="Amenities" value={acc.amenities.join(', ')} />
                )}
                {acc.bookingLink && (
                  <a href={acc.bookingLink} target="_blank" rel="noopener noreferrer" className="text-sm text-indigo-500 hover:text-indigo-700 hover:underline">
                    Check Availability
                  </a>
                )}
              </div>
            ))}
          </div>
        </InfoSection>
      )}
      
      {itinerary.weatherForecast && itinerary.weatherForecast.length > 0 && (
        <InfoSection title="Weather Forecast" icon={<div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: WEATHER_ICON_SVG }} />} titleClassName="text-sky-700">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {itinerary.weatherForecast.map((forecast, index) => (
              <div key={index} className="p-4 border border-sky-200 rounded-lg shadow-sm bg-sky-50">
                <h5 className="font-semibold text-md text-sky-800">{forecast.date} ({forecast.dayName || 'Date'})</h5>
                <DetailItem label="High" value={forecast.highTemp} />
                <DetailItem label="Low" value={forecast.lowTemp} />
                <DetailItem label="Condition" value={forecast.condition} />
                {forecast.precipitationChance && <DetailItem label="Precip." value={forecast.precipitationChance} />}
              </div>
            ))}
          </div>
        </InfoSection>
      )}

      <InfoSection title="Daily Itinerary">
        <div className="space-y-8">
          {itinerary.dailyPlan.map((day) => (
            <DayCard key={day.day} day={day} />
          ))}
        </div>
      </InfoSection>

      {itinerary.packingList && itinerary.packingList.length > 0 && (
        <InfoSection title="Suggested Packing List" icon={<div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: PACKING_ICON_SVG }} />}>
          <ul className="list-disc list-inside text-slate-600 space-y-1 columns-1 sm:columns-2 md:columns-3">
            {itinerary.packingList.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </InfoSection>
      )}

      {itinerary.budgetEstimate && (
        <InfoSection title="Budget Estimate" icon={<div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: BUDGET_ICON_SVG }} />}>
          <DetailItem label="Total Estimated Cost" value={`${itinerary.budgetEstimate.total || 'N/A'} ${itinerary.budgetEstimate.currency || ''}`} className="text-xl"/>
          {itinerary.budgetEstimate.breakdown && (
            <div className="mt-4">
              <h5 className="text-md font-semibold text-slate-700 mb-2">Breakdown:</h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1">
                {Object.entries(itinerary.budgetEstimate.breakdown).map(([key, value]) => (
                  <DetailItem key={key} label={key.charAt(0).toUpperCase() + key.slice(1)} value={value as string} />
                ))}
              </div>
            </div>
          )}
        </InfoSection>
      )}
      
      {(itinerary.visaRequirements || itinerary.healthAndSafety || itinerary.localCustoms || itinerary.language || itinerary.currencyInfo || itinerary.transportationWithinDestination || itinerary.emergencyContacts || itinerary.additionalTips) && (
        <InfoSection title="Additional Information" icon={<div className="w-6 h-6" dangerouslySetInnerHTML={{ __html: INFO_ICON_SVG }} />}>
            <DetailItem label="Visa Requirements" value={itinerary.visaRequirements} />
            {itinerary.healthAndSafety && (
                <div className="mt-3 pt-3 border-t border-slate-200">
                    <h5 className="font-semibold text-slate-700 mb-1">Health & Safety:</h5>
                    <DetailItem label="Vaccinations" value={itinerary.healthAndSafety.vaccinations?.join(', ')} subItems />
                    <DetailItem label="Travel Insurance" value={itinerary.healthAndSafety.travelInsurance} subItems />
                    {itinerary.healthAndSafety.localSafetyTips && itinerary.healthAndSafety.localSafetyTips.length > 0 && (
                        <DetailItem label="Local Safety Tips" value={<ul className="list-disc list-inside ml-4">{itinerary.healthAndSafety.localSafetyTips.map((tip, i) => <li key={i}>{tip}</li>)}</ul>} subItems />
                    )}
                </div>
            )}
             {itinerary.localCustoms && itinerary.localCustoms.length > 0 && (
                 <div className="mt-3 pt-3 border-t border-slate-200">
                    <DetailItem label="Local Customs" value={<ul className="list-disc list-inside ml-4">{itinerary.localCustoms.map((custom, i) => <li key={i}>{custom}</li>)}</ul>} />
                 </div>
            )}
            {itinerary.language && (
                <div className="mt-3 pt-3 border-t border-slate-200">
                    <h5 className="font-semibold text-slate-700 mb-1">Language:</h5>
                    <DetailItem label="Primary Spoken" value={itinerary.language.primarySpoken} subItems />
                    <DetailItem label="Secondary Spoken" value={itinerary.language.secondarySpoken?.join(', ')} subItems />
                    <DetailItem label="Itinerary Language" value={itinerary.language.itineraryGeneratedInLanguage} subItems />
                    {itinerary.language.usefulPhrases && itinerary.language.usefulPhrases.length > 0 && (
                         <DetailItem label="Useful Phrases" value={
                            <ul className="space-y-1 mt-1">{itinerary.language.usefulPhrases.map((phrase, i) => <li key={i}><span className="font-medium">{phrase.phrase}</span>: {phrase.translation} {phrase.targetLanguage && <span className="text-xs italic">({phrase.targetLanguage})</span>}</li>)}</ul>
                         } subItems />
                    )}
                </div>
            )}
            {itinerary.currencyInfo && (
                <div className="mt-3 pt-3 border-t border-slate-200">
                     <h5 className="font-semibold text-slate-700 mb-1">Currency:</h5>
                    <DetailItem label="Local Currency" value={itinerary.currencyInfo.localCurrency} subItems />
                    <DetailItem label="Exchange Rate" value={itinerary.currencyInfo.exchangeRate} subItems />
                    <DetailItem label="Tipping Etiquette" value={itinerary.currencyInfo.tippingEtiquette} subItems />
                </div>
            )}
            {itinerary.transportationWithinDestination && (
                 <div className="mt-3 pt-3 border-t border-slate-200">
                    <h5 className="font-semibold text-slate-700 mb-1">Getting Around:</h5>
                    <DetailItem label="Recommendations" value={<ul className="list-disc list-inside ml-4">{itinerary.transportationWithinDestination.recommendations.map((rec, i) => <li key={i}>{rec}</li>)}</ul>} subItems />
                    {itinerary.transportationWithinDestination.apps && itinerary.transportationWithinDestination.apps.length > 0 && (
                        <DetailItem label="Useful Apps" value={itinerary.transportationWithinDestination.apps.join(', ')} subItems />
                    )}
                </div>
            )}
             {itinerary.emergencyContacts && (
                <div className="mt-3 pt-3 border-t border-slate-200">
                    <h5 className="font-semibold text-slate-700 mb-1">Emergency Contacts:</h5>
                    <DetailItem label="Local Emergency" value={itinerary.emergencyContacts.localEmergencyNumber} subItems />
                    <DetailItem label="Police" value={itinerary.emergencyContacts.police} subItems />
                    <DetailItem label="Ambulance" value={itinerary.emergencyContacts.ambulance} subItems />
                    <DetailItem label="Embassy" value={itinerary.emergencyContacts.embassy} subItems />
                </div>
            )}
            {itinerary.additionalTips && itinerary.additionalTips.length > 0 && (
                 <div className="mt-3 pt-3 border-t border-slate-200">
                    <DetailItem label="Additional Tips" value={<ul className="list-disc list-inside ml-4">{itinerary.additionalTips.map((tip, i) => <li key={i}>{tip}</li>)}</ul>} />
                 </div>
            )}
        </InfoSection>
      )}
      
    </div>
  );
};

export default ItineraryDisplay;

const style = document.createElement('style');
style.innerHTML = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fadeIn {
    animation: fadeIn 0.5s ease-out forwards;
  }
`;
document.head.appendChild(style);