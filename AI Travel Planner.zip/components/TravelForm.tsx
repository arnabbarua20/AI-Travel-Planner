
import React, { useState, FormEvent } from 'react';
import { TravelPreferences } from '../types';
import { TRAVEL_STYLES, BUDGET_OPTIONS } from '../constants';

interface TravelFormProps {
  onSubmit: (preferences: TravelPreferences) => void;
  isLoading: boolean;
}

const TravelForm: React.FC<TravelFormProps> = ({ onSubmit, isLoading }) => {
  const [destination, setDestination] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [numTravelers, setNumTravelers] = useState<number>(1);
  const [travelStyle, setTravelStyle] = useState<string>(TRAVEL_STYLES[0]);
  const [budget, setBudget] = useState<string>(BUDGET_OPTIONS[1]);
  const [specificRequests, setSpecificRequests] = useState<string>('');
  const [preferredLanguageForItinerary, setPreferredLanguageForItinerary] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);

  const today = new Date().toISOString().split('T')[0];

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!destination || !startDate || !endDate) {
      setFormError('Destination, Start Date, and End Date are required.');
      return;
    }
    if (new Date(startDate) > new Date(endDate)) {
        setFormError('Start Date cannot be after End Date.');
        return;
    }
    if (new Date(startDate) < new Date(today) && startDate !== today) {
        setFormError('Start Date cannot be in the past.');
        return;
    }

    onSubmit({ destination, startDate, endDate, numTravelers, travelStyle, budget, specificRequests, preferredLanguageForItinerary });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {formError && (
        <div className="p-3 bg-red-100 border border-red-400 text-red-700 rounded-md">
          {formError}
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="destination" className="block text-sm font-medium text-slate-700 mb-1">
            Destination
          </label>
          <input
            type="text"
            id="destination"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="e.g., Paris, France"
            required
          />
        </div>
         <div>
          <label htmlFor="numTravelers" className="block text-sm font-medium text-slate-700 mb-1">
            Number of Travelers
          </label>
          <input
            type="number"
            id="numTravelers"
            value={numTravelers}
            onChange={(e) => setNumTravelers(Math.max(1, parseInt(e.target.value)))}
            min="1"
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="startDate" className="block text-sm font-medium text-slate-700 mb-1">
            Start Date
          </label>
          <input
            type="date"
            id="startDate"
            value={startDate}
            min={today}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          />
        </div>
        <div>
          <label htmlFor="endDate" className="block text-sm font-medium text-slate-700 mb-1">
            End Date
          </label>
          <input
            type="date"
            id="endDate"
            value={endDate}
            min={startDate || today}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="travelStyle" className="block text-sm font-medium text-slate-700 mb-1">
            Travel Style
          </label>
          <select
            id="travelStyle"
            value={travelStyle}
            onChange={(e) => setTravelStyle(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white"
          >
            {TRAVEL_STYLES.map((style) => (
              <option key={style} value={style}>
                {style}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="budget" className="block text-sm font-medium text-slate-700 mb-1">
            Budget Preference
          </label>
          <select
            id="budget"
            value={budget}
            onChange={(e) => setBudget(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-white"
          >
            {BUDGET_OPTIONS.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <div>
          <label htmlFor="preferredLanguage" className="block text-sm font-medium text-slate-700 mb-1">
            Preferred Language for Itinerary (Optional)
          </label>
          <input
            type="text"
            id="preferredLanguage"
            value={preferredLanguageForItinerary}
            onChange={(e) => setPreferredLanguageForItinerary(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="e.g., Spanish, French (defaults to English)"
          />
      </div>

      <div>
        <label htmlFor="specificRequests" className="block text-sm font-medium text-slate-700 mb-1">
          Specific Requests or Interests (Optional)
        </label>
        <textarea
          id="specificRequests"
          value={specificRequests}
          onChange={(e) => setSpecificRequests(e.target.value)}
          rows={3}
          className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          placeholder="e.g., Must visit the Eiffel Tower, interested in cooking classes, prefer vegetarian food."
        />
      </div>

      <div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-lg text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-slate-400 disabled:cursor-not-allowed transition-colors duration-150"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating Plan...
            </>
          ) : (
            'Generate Travel Plan'
          )}
        </button>
      </div>
    </form>
  );
};

export default TravelForm;
